﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    private Rigidbody2D rb;
    private float currentX;
    private float currentY;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void MoveLeft(){
        currentX = rb.position.x;
        currentY = rb.position.y;
        rb.position = new Vector2(currentX-4,currentY);
    }

    public void MoveRight(){
        currentX = rb.position.x;
        currentY = rb.position.y;
        rb.position = new Vector2(currentX+4,currentY);
    }

}